const express = require("express");
const bodyParser = require("body-parser");
const request = require("request");
const https = require("https");

// const { stringify } = require("querystring");
// const { response } = require("express");

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

app.get("/", function (req, res) {
    res.sendFile(__dirname + "/index.html")
});


app.post("/", function (req, res) {

    // console.log("Post Request Revieved");
    const fname = req.body.fName;
    const lname = req.body.lName;
    const email = req.body.email;
    // console.log(email);


    const data = {
        members:[
            {
                "email_address": email,
                "status": "subscribed",
                "merge_fields": {
                    "FNAME": fname,
                    "LNAME": lname
                }
            }
        ]
        // "auth":"username:a69b919b9b9dc2136723ba1d68a3a58b-us21",  
    };

    const jsonData = JSON.stringify(data);
    const url = "https://us21.api.mailchimp.com/3.0/lists/94bd85bb12";


    const option = {
        method:"POST",
        auth:"user:a69b919b9b9dc2136723ba1d68a3a58b-us21"
    }

     const request = https.request(url, option, function(response){
        response.on("data", function(data){
            console.log(JSON.parse(data));
        });

        if(response.statusCode === 200){
            res.sendFile(__dirname + "/sucess.html")
        }
        else{
            res.sendFile(__dirname + "/failure.html");
        }
    });

    request.write(jsonData);
    request.end();


});




app.listen(3000, function () {
    console.log("server is running on port 3000");
})


// api key : 
// a69b919b9b9dc2136723ba1d68a3a58b-us21

//audiance unique id:
//94bd85bb12